/* CADEM SMART's color palette */

export const CADEM_COLOR_WHITE = '#ffffff';
export const CADEM_COLOR_WHITE_GREY = '#f7f7f7';
export const CADEM_COLOR_GREY_SHADOW = '#dfe3ee';
export const CADEM_COLOR_WHITE_BLUE = '#8b9dc3';
export const CADEM_COLOR_BLUE = '#3b5998';
export const CADEM_COLOR_ACTIVE_TAB = '#3b5998';
